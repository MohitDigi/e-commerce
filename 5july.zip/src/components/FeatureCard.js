import React from 'react'
import "../Assets/FeatureCard.css"

const FeatureCard = () => {
  return (
    <>
   
    </>
  )
}

export default FeatureCard