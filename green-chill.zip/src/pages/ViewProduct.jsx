import React from "react";
// import TopHeader from "../components/TopHeader";
// import LogoHeader from "../components/LogoHeader";
// import Navbar from "../components/Navbar";
import Description from "../components/Description";


const ViewProduct = () => {
  return (
    <>
      {/* <header>
        <TopHeader />
        <LogoHeader />
        <Navbar />
      </header> */}
      <Description />
      
    </>
  );
};

export default ViewProduct;
